import asyncio
import os
import signal

from app import telegram_bot, storage, core, google_drive


async def stop():
    print('Stopping bot...')
    await telegram_bot.shutdown()
    await storage.disconnect()


async def _signal_handler():
    await stop()
    asyncio.get_running_loop().call_soon(asyncio.get_running_loop().stop)


async def main():
    print(f'Google Drive Bot is starting...')

    os.makedirs('data/', exist_ok=True)

    global _loop
    _loop = asyncio.get_running_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        _loop.add_signal_handler(sig, lambda: asyncio.create_task(_signal_handler()))

    await core.connect_to_panel()
    await google_drive.boot()
    await storage.connect()

    global _bot_task
    _bot_task = asyncio.create_task(telegram_bot.connect())
    print('Google Drive Bot has started')

    # try:
    await _bot_task
    # except asyncio.CancelledError:
    #     await telegram_bot.shutdown()


if __name__ == '__main__':
    # try:
    asyncio.run(main())
    # except (KeyboardInterrupt, SystemExit):
    #     print("Bot is shutting down...")
    # asyncio.run(main())
