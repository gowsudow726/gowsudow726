import base64
from datetime import datetime


def encode_to_base64(arr: list[str]) -> str:
    combined_string = "\n".join(arr)
    encoded_string = base64.b64encode(combined_string.encode()).decode()
    return encoded_string

    # def encode_string(string: str) -> str:
    #     return base64.b64encode(string.encode('utf-8')).decode('utf-8')
    #
    # return [encode_string(string) for string in arr]


def format_date(unix_time):
    return datetime.utcfromtimestamp(unix_time).strftime('%H:%M:%S %d/%m/%Y')