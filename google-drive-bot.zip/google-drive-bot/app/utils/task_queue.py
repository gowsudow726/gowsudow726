import asyncio
from collections import defaultdict
from typing import Dict, Any, Coroutine


class TaskQueue:
    def __init__(self):
        self.user_queues: Dict[int, asyncio.Queue] = defaultdict(asyncio.Queue)
        self.user_locks: Dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def add_task(self, user_id: int, task: Coroutine[Any, Any, Any]) -> Any:
        if self.has_tasks(user_id):
            raise Exception('User already has a pending task')

        future = asyncio.Future()
        await self.user_queues[user_id].put((task, future))
        if not self.user_locks[user_id].locked():
            asyncio.create_task(self._process_queue(user_id))
        return await future

    async def _process_queue(self, user_id: int):
        async with self.user_locks[user_id]:
            while not self.user_queues[user_id].empty():
                task, future = await self.user_queues[user_id].get()
                try:
                    result = await task
                    future.set_result(result)
                except Exception as e:
                    future.set_exception(e)

    def has_tasks(self, user_id: int) -> bool:
        return self.user_locks[user_id].locked() or not self.user_queues[user_id].empty()
