import toml

from app.models.telegram_user import TelegramUser

_config = toml.load('config.toml')

HOST = _config.get('marzban', {}).get('host', '')
PORT = _config.get('marzban', {}).get('port', 8000)
SSL = _config.get('marzban', {}).get('ssl', False)
USERNAME = _config.get('marzban', {}).get('username', '')
PASSWORD = _config.get('marzban', {}).get('password', '')

GOOGLE_DRIVE_CREDENTIALS_PATH = _config.get('google_drive', {}).get('credentials', 'credentials.json')
GOOGLE_DRIVE_FOLDER = _config.get('google_drive', {}).get('folder', 'subscriptions')
GOOGLE_DRIVE_FILE_FORMAT = _config.get('google_drive', {}).get('file_name_format', 'Subscription - {username}')
GOOGLE_DRIVE_EMAIL = _config.get('google_drive', {}).get('email', None)

_webhook_path = _config.get('marzban', {}).get('webhook', {})
WEBHOOK_PORT = _webhook_path.get('port', 8020)
WEBHOOK_SECRET = _webhook_path.get('secret', '')

TELEGRAM_API_TOKEN = _config.get('telegram', {}).get('api_token', '')
TELEGRAM_USERS = [TelegramUser(user.get('username', ''), user.get('is_sudo', False), user.get('id', -1))
                  for user in _config.get('users', [])]




# [marzban.webhook]
# port = 8020
# secret = "my-secret"