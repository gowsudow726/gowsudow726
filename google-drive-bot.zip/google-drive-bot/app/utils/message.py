import toml

_config = toml.load('message.toml')

TELEGRAM_KB_SEARCH = _config.get('telegram_kb_search', 'Search')
TELEGRAM_KB_SYNC_CONFIGS = _config.get('telegram_kb_sync_configs', 'Synchronize configs')
TELEGRAM_WELCOME = _config.get('telegram_welcome', 'Welcome! Select action')
TELEGRAM_SYNC_IN_PROGRESS = _config.get('telegram_sync_in_progress', 'Configs are already being synchronized. Wait for it to be completed')
TELEGRAM_SYNC_PREPARE = _config.get('telegram_sync_preparing', 'Synchronization is starting. Wait a moment...')
TELEGRAM_SYNC_NO_CONFIGS_TO_SYNC = _config.get('telegram_sync_no_configs_to_sync', 'All configs are already synchronized')
TELEGRAM_SYNC_COMPLETED = _config.get('telegram_sync_completed', 'Synchronization is completed at {completed_at}')
TELEGRAM_SYNC_STARTED = _config.get('telegram_sync_started', 'Synchronization has started. You will receive a notification as soon as it is completed.\n\nStarted at {started_at}\nConfigs need to be synced: {configs_to_sync}\nAll configs: {all_configs}')
TELEGRAM_SEARCH_USAGE = _config.get('telegram_search_usage', 'Enter username:')
TELEGRAM_SEARCH_INFO = _config.get('telegram_search_info', 'Username: {username}\nExpiry date: {expire_at}\nTraffic: {traffic}\nLast sync: {last_sync}\nGoogle Drive link: {link}')
TELEGRAM_SEARCH_NOT_FOUND = _config.get('telegram_search_not_found', 'User not found')
