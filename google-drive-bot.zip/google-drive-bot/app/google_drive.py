import json

import os

import aiofiles
# from aiogoogle.auth.creds import ServiceAccountCreds

from app.aiogoogle import Aiogoogle
from app.aiogoogle.auth.creds import ServiceAccountCreds
from app.aiogoogle.models import Response
from app.utils import config

SCOPES = [
    'https://www.googleapis.com/auth/drive.file'
]
FOLDER_ID = -1
cached_path = 'data/google_drive_cache.json'


class GoogleDrive:

    def __init__(self):
        self.service = None
        service_credentials = json.load(open(config.GOOGLE_DRIVE_CREDENTIALS_PATH))
        os.makedirs('data/temp/', exist_ok=True)
        creds = ServiceAccountCreds(scopes=SCOPES, **service_credentials)
        self.googleapi = Aiogoogle(service_account_creds=creds)

    async def auth(self):
        self.service = await self.googleapi.discover('drive', 'v3')

    async def create_folder(self, folder_name: str, parent: str = None) -> Response:
        if self.service is None:
            await self.auth()

        folder_metadata = {
            "name": folder_name,
            "mimeType": "application/vnd.google-apps.folder",
            "parents": [parent] if parent else [],
        }

        response = await self.googleapi.as_service_account(
            self.service.files.create(json=folder_metadata)
        )

        return response

    async def grant_permission_to_user(self, object_id: str, type: str, role: str, email: str) -> Response:
        if self.service is None:
            await self.auth()

        permission = {
            'type': type,
            'role': role,
            'emailAddress': email
        }

        response = await self.googleapi.as_service_account(
            self.service.permissions.create(fileId=object_id, json=permission)
        )

        return response

    async def grant_permission(self, object_id: str, type: str, role: str) -> Response:
        if self.service is None:
            await self.auth()

        permission = {
            'type': type,
            'role': role
        }

        response = await self.googleapi.as_service_account(
            self.service.permissions.create(fileId=object_id, json=permission)
        )

        return response

    async def update_file(self, file_name: str, file_id: str, content: list[str]) -> Response:
        if self.service is None:
            await self.auth()

        file_metadata = {
            "name": file_name,
            "mimeType": "text/plain"
        }

        temp_file_path = f'data/temp/{file_id}.txt'
        async with aiofiles.open(temp_file_path, mode='w') as f:
            for string in content:
                await f.write(string + '\n')

        try:
            response = await self.googleapi.as_service_account(
                self.service.files.update(
                    fileId=file_id,
                    data=file_metadata,
                    upload_file=temp_file_path,
                    multipart=False
                )
            )
        except Exception:
            os.remove(temp_file_path)
            raise

        os.remove(temp_file_path)

        # res = await self.googleapi.as_service_account(
        #     self.service.files.get(fileId=file_id, download_file='/home/user/PycharmProjects/google-drive-bot/downloaded.txt', alt='media')
        # )
        # print(res)

        return response

    async def create_file(self, file_name: str, content: list[str], folder_id: str = None) -> Response:
        if self.service is None:
            await self.auth()

        file_metadata = {
            "name": file_name,
            "mimeType": "text/plain",
            "parents": [folder_id] if folder_id else []
        }
        # print(f'Folder: {folder_id}')
        # file_data = '\n'.join(content).encode('utf-8')
        # file_data = BytesIO(file_data)
        # raise Exception
        temp_file_path = f'data/temp/{file_name}.txt'
        async with aiofiles.open(temp_file_path, mode='w') as f:
            for string in content:
                await f.write(string + '\n')

        # print(temp_file_path)
        # raise Exception
        try:
            response = await self.googleapi.as_service_account(
                self.service.files.create(
                    json=file_metadata,
                    upload_file=temp_file_path
                )
            )
        except Exception:
            os.remove(temp_file_path)
            raise

        os.remove(temp_file_path)

        return response

    async def __aexit__(self, *args):
        await self.googleapi.__aexit__(*args)

    async def __aenter__(self):
        await self.googleapi.__aenter__()
        return self


def get_download_link(file_id: str) -> str:
    return f"https://drive.google.com/uc?id={file_id}&export=download"


def should_create_folder() -> bool:
    if not os.path.isfile(cached_path):
        return True
    else:
        with open(cached_path, 'r') as file:
            cached_data = json.loads(file.read())
        return cached_data['folder_name'] != config.GOOGLE_DRIVE_FOLDER


def update_google_drive_cache(folder_name, folder_id):
    cached_data = {
        'folder_name': folder_name,
        'folder_id': folder_id
    }
    with open(cached_path, 'w') as file:
        file.write(json.dumps(cached_data))


async def boot():
    global FOLDER_ID, cached_path

    if should_create_folder():
        async with GoogleDrive() as drive:
            response = await drive.create_folder(folder_name=config.GOOGLE_DRIVE_FOLDER)
            FOLDER_ID = response['id']
            if config.GOOGLE_DRIVE_EMAIL:
                await drive.grant_permission_to_user(object_id=FOLDER_ID, type='user', role='writer',
                                                     email=config.GOOGLE_DRIVE_EMAIL)
            update_google_drive_cache(folder_name=config.GOOGLE_DRIVE_FOLDER, folder_id=FOLDER_ID)
    else:
        FOLDER_ID = json.load(open(cached_path, 'r'))['folder_id']
