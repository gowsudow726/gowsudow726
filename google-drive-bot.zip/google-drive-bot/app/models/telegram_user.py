class TelegramUser():
    def __init__(self, username, is_sudo, id):
        self.username = username
        self.is_sudo = is_sudo
        self.id = id