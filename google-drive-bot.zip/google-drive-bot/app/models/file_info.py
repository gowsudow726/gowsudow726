class FileInfo:
    def __init__(self, username: str, filename: str, content: list[str], exists: bool, status: int, file_id = None, updated_at = None):
        self.username = username
        self.exists = exists
        self.file_id = file_id
        self.filename = filename
        self.content = content
        self.updated_at = updated_at
        self.status = status

    def __str__(self) -> str:
        return (f"FileInfo(username: {self.username}, filename: {self.filename}, exists: {self.exists}, "
                f"file_id: {self.file_id}, content:{self.content}, updated_at={self.updated_at}, status={self.status}")
