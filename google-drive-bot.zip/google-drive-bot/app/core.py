import asyncio
import random
import time
import traceback
from datetime import datetime

import httpx

import app
from app import storage
from app.aiogoogle import HTTPError
from app.google_drive import GoogleDrive
from app.marzban_api import MarzbanAPI
from app.models.file_info import FileInfo
from app.models.telegram_user import TelegramUser
from app.storage import Status
from app.utils import config, message, utils
from app.utils.task_queue import TaskQueue

host = f'{"https" if config.SSL else "http"}://{config.HOST}:{config.PORT}'
marzban_api = MarzbanAPI(base_url=host)
maximum_backoff = 32
task_queue = TaskQueue()


async def subtask(task):
    result = None
    try:
        result = await task
    except HTTPError as err:
        if err.res.status_code == 403 or err.res.status_code == 429:
            raise
        raise Exception(err)
    except Exception as e:
        raise
    return result


async def handle_subtask(task):
    retry_attempts = 0
    result = None
    while True:
        try:
            result = await subtask(task)
            break
        except HTTPError as err:
            if err.res.status_code == 403 or err.res.status_code == 429:
                print(f'Rate limit exceeded. Retrying... {task}')
                retry_attempts += 1
                delay = min(2 ** retry_attempts + random.random(), maximum_backoff)
                await asyncio.sleep(delay)
        except Exception:
            raise
    return result


async def worker(queue, event):
    while True:
        await event.wait()
        task = await queue.get()
        if task is None:
            queue.task_done()
            break
        try:
            await task
        except Exception:
            pass
        finally:
            queue.task_done()


async def process_file(google_drive, file: FileInfo):
    try:
        content = [utils.encode_to_base64(file.content)]
        if not file.exists:
            response = await handle_subtask(asyncio.create_task(google_drive.create_file(file_name=file.filename, folder_id=app.google_drive.FOLDER_ID, content=content)))
            if response is None:
                raise Exception
            file_id = response['id']
            file.file_id = file_id
            file.exists = True
            file.updated_at = int(time.time())
            file.status = Status.SYNCED.value
            await storage.update_file(file)
            await handle_subtask(asyncio.create_task(google_drive.grant_permission(object_id=file_id, type='anyone', role='reader')))
            return

        await handle_subtask(asyncio.create_task(google_drive.update_file(file_name=file.filename, file_id=file.file_id, content=content)))
        file.updated_at = int(time.time())
        file.status = Status.SYNCED.value
        await storage.update_file(file)
    except Exception:
        file.status = Status.SYNC_FAILED.value
        await storage.update_file(file)
        print(traceback.format_exc(), flush=True)
        pass


async def sync_files(files: list[FileInfo]):
    async with GoogleDrive() as drive:
        await drive.auth()

        tasks = [process_file(google_drive=drive, file=file) for file in files]
        queue = asyncio.Queue()
        event = asyncio.Event()
        event.set()

        for task in tasks:
            await queue.put(task)

        number_of_workers = 10
        workers = [asyncio.create_task(worker(queue, event)) for _ in range(number_of_workers)]

        start = datetime.now()
        await queue.join()

        for _ in range(number_of_workers):
            await queue.put(None)

        await asyncio.gather(*workers)
        print(f'{len(files)} tasks completed in {datetime.now() - start}')


async def sync_users(admin: TelegramUser):
    # fix circular import
    from app.telegram_bot import bot

    if task_queue.has_tasks(admin.id):
        await bot.send_message(admin.id, message.TELEGRAM_SYNC_IN_PROGRESS)
        return

    await bot.send_message(admin.id, message.TELEGRAM_SYNC_PREPARE)

    if admin.is_sudo:
        users = await marzban_api.get_users()
    else:
        users = await marzban_api.get_users_by_admin(admin.username)

    if users is None:
        await bot.send_message(admin.id, f'Failed to fetch users from Marzban Panel')
        return

    # await storage.sync_users(users, delete_non_existent_users=admin.is_sudo)
    await storage.sync_users(users, delete_non_existent_users=False)
    files = await storage.get_files_waiting_to_sync(filtered_usernames=[user.username for user in users])

    if not files:
        await bot.send_message(admin.id, message.TELEGRAM_SYNC_NO_CONFIGS_TO_SYNC)
        return

    started_at = int(time.time())
    await bot.send_message(admin.id, message.TELEGRAM_SYNC_STARTED
                           .replace('{started_at}', utils.format_date(started_at))
                           .replace('{configs_to_sync}', str(len(files)))
                           .replace('{all_configs}', str(len(users))))

    await task_queue.add_task(admin.id, sync_files(files))
    # successfully_synced = 0

    completed_at = int(time.time())
    await bot.send_message(admin.id, message.TELEGRAM_SYNC_COMPLETED
                           .replace('{completed_at}', utils.format_date(completed_at))
                           .replace('{configs}', str(len(files))))


async def connect_to_panel():
    try:
        await marzban_api.connect(username=config.USERNAME, password=config.PASSWORD)
    except httpx.ConnectError as ex:
        raise httpx.ConnectError(f'Failed to connect to Marzban: is it running? {ex}')
        # raise
