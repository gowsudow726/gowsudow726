import asyncio
import json
from enum import Enum

import aiosqlite

from app.marzban_api import UserResponse
from app.models.file_info import FileInfo
from app.utils import config

global connection
lock = asyncio.Lock()


class Status(Enum):
    NEED_SYNC = 1
    SYNCING = 2
    SYNCED = 3
    SYNC_FAILED = 4
    DELETED = 5


async def connect():
    global connection
    connection = await aiosqlite.connect('data/database.db')
    await connection.execute('CREATE TABLE IF NOT EXISTS users ('
                             'username VARCHAR(32) NOT NULL,'
                             'file_id VARCHAR(44),'
                             'content TEXT,'
                             'status INT,'
                             'updated_at INT DEFAULT -1)')
    await connection.execute('CREATE INDEX IF NOT EXISTS idx_users ON users(username)')
    await connection.commit()


async def sync_users(marzban_users: list[UserResponse], delete_non_existent_users=False):
    async with lock:
        try:
            temp_table = 'users_temp'
            # cursor = await connection.execute('BEGIN TRANSACTION')
            cursor = await connection.execute(f'''
                CREATE TABLE {temp_table} (
                    username VARCHAR(32) NOT NULL,
                    file_id VARCHAR(44),
                    content TEXT,
                    status INT,
                    updated_at INT DEFAULT -1
                )
            ''')
            await cursor.execute(f'CREATE INDEX idx_{temp_table} ON {temp_table}(username)')

            await cursor.executemany(f'INSERT INTO {temp_table} (username, content, status) VALUES (?, ?, ?)',
                                     [(
                                         marzban_user.username,
                                         json.dumps([link for link in marzban_user.links if link != 'False']),
                                         Status.NEED_SYNC.value
                                     ) for marzban_user in marzban_users])

            await cursor.execute(f'''
                        UPDATE {temp_table}
                        SET file_id = users.file_id, 
                            status = users.status, 
                            updated_at = users.updated_at
                        FROM users
                        WHERE {temp_table}.username = users.username
                    ''')

            await cursor.execute(f'''
                        UPDATE {temp_table}
                        SET status = {Status.NEED_SYNC.value}
                        FROM users
                        WHERE {temp_table}.username = users.username AND {temp_table}.content <> users.content
                    ''')

            if not delete_non_existent_users:
                await cursor.execute(f'''
                    INSERT INTO {temp_table} (username, file_id, content, status, updated_at) 
                    SELECT username, file_id, content, {Status.DELETED.value}, updated_at 
                    FROM users
                    WHERE NOT EXISTS (SELECT 1 FROM {temp_table} WHERE {temp_table}.username = users.username)
                ''')

            await cursor.execute('DROP TABLE IF EXISTS users')
            await cursor.execute(f'DROP INDEX idx_{temp_table}')
            await cursor.execute(f'ALTER TABLE {temp_table} RENAME TO users')
            await cursor.execute(f'CREATE INDEX idx_users ON users(username)')

            await connection.commit()

        except Exception as ex:
            await connection.rollback()
            raise ex


async def fix_failed_updates_all():
    await connection.execute('UPDATE users SET status=? WHERE status=?',
                             [Status.SYNC_FAILED.value, Status.SYNCING.value])
    await connection.commit()


async def fix_failed_updates(arr: list[FileInfo]):
    await connection.executemany('UPDATE users SET status=? WHERE status=? AND username=?',
                                 [(Status.SYNC_FAILED.value, Status.SYNCING.value, fileinfo.username)
                                  for fileinfo in arr])
    await connection.commit()


async def disconnect():
    await connection.close()


async def get_file_linked_to_user(name: str) -> FileInfo | None:
    async with connection.execute('SELECT username, file_id, content, updated_at, status FROM users WHERE '
                                  'username=? LIMIT 1', [name]) as cursor:
        record = await cursor.fetchone()
        if record:
            status = record[4]
            username = record[0]
            filename = config.GOOGLE_DRIVE_FILE_FORMAT.replace('{username}', username)
            updated_at = record[3]
            exists = updated_at != -1

            return FileInfo(username=username, filename=filename, exists=exists, file_id=record[1],
                            content=json.loads(record[2]), updated_at=updated_at, status=status)

        return None


async def update_file(file: FileInfo):
    await connection.execute('UPDATE users SET file_id=?, status=?, updated_at=? WHERE username=?',
                             [file.file_id, file.status, file.updated_at, file.username])
    await connection.commit()


async def delete_user(name: str):
    await connection.execute('DELETE FROM users WHERE username=?', [name])
    await connection.commit()


async def get_files_waiting_to_sync(filtered_usernames: list[str] = None) -> list[FileInfo]:
    files = []
    if filtered_usernames is None:
        async with connection.execute('SELECT username, file_id, content, updated_at, status FROM users') as cursor:
            records = await cursor.fetchall()
            for record in records:
                status = record[4]
                # print()
                if status not in [Status.NEED_SYNC.value, Status.SYNC_FAILED.value]:
                    continue

                username = record[0]
                filename = config.GOOGLE_DRIVE_FILE_FORMAT.replace('{username}', username)
                updated_at = record[3]
                exists = record[3] != -1

                files.append(FileInfo(username=username, filename=filename, exists=exists, file_id=record[1],
                                      content=json.loads(record[2]), updated_at=updated_at, status=status))
    else:
        batch_size = 1000
        for start in range(0, len(filtered_usernames), batch_size):
            batch = filtered_usernames[start:start + batch_size]
            placeholders = ','.join(['?'] * len(batch))
            query = f"SELECT username, file_id, content, updated_at, status FROM users WHERE username IN ({placeholders})"

            async with connection.execute(query, batch) as cursor:
                records = await cursor.fetchall()
                for record in records:
                    status = record[4]
                    if status not in [Status.NEED_SYNC.value, Status.SYNC_FAILED.value]:
                        continue
                    username = record[0]
                    filename = config.GOOGLE_DRIVE_FILE_FORMAT.replace('{username}', username)
                    updated_at = record[3]
                    exists = record[3] != -1

                    files.append(FileInfo(username=username, filename=filename, exists=exists, file_id=record[1],
                                          content=json.loads(record[2]), updated_at=updated_at, status=status))

    return files
