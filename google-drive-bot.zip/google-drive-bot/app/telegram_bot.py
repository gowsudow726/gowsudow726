import asyncio
from functools import wraps

from aiogram import Bot, Dispatcher, types
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.utils.formatting import as_list
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from app import storage, core, google_drive
from app.core import marzban_api
from app.utils import message, config, utils


dispatcher = Dispatcher()

reply_kb_builder = ReplyKeyboardBuilder()
btn_search = types.KeyboardButton(text=message.TELEGRAM_KB_SEARCH)
btn_sync_configs = types.KeyboardButton(text=message.TELEGRAM_KB_SYNC_CONFIGS)
reply_kb_builder.add(btn_search)
reply_kb_builder.add(btn_sync_configs)
reply_kb_builder.adjust(1)
reply_kb = reply_kb_builder.as_markup(resize_keyboard=True, one_time_keyboard=False)

bot = Bot(token=config.TELEGRAM_API_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))


def _auth_user(user_id: int):
    for telegram_user in config.TELEGRAM_USERS:
        if telegram_user.id == user_id:
            return True
    return False


def _get_user_by_id(user_id: int):
    for telegram_user in config.TELEGRAM_USERS:
        if telegram_user.id == user_id:
            return telegram_user
    return None


async def answer(msg: types.Message, text: str, reply_markup = None):
    a = as_list(text, sep='\n')
    await msg.answer(**a.as_kwargs(), reply_markup=reply_markup)


def auth_user(handler):
    @wraps(handler)
    async def wrapper(msg: types.Message, *args, **kwargs):
        if _auth_user(msg.from_user.id):
            await handler(msg, *args, **kwargs)
    return wrapper


@dispatcher.message(CommandStart())
@auth_user
async def send_welcome(msg: types.Message):
    await answer(msg, message.TELEGRAM_WELCOME, reply_markup=reply_kb)


@dispatcher.message(lambda msg: msg.text == message.TELEGRAM_KB_SYNC_CONFIGS)
@auth_user
async def sync_configs(msg: types.Message):
    telegram_user = _get_user_by_id(msg.from_user.id)
    await core.sync_users(telegram_user)


@dispatcher.message(lambda msg: msg.text == message.TELEGRAM_KB_SEARCH)
@auth_user
async def search_user_kb(msg: types.Message):
    await answer(msg, message.TELEGRAM_SEARCH_USAGE)


@dispatcher.message()
@auth_user
async def search_user(msg: types.Message):
    username = msg.text
    telegram_user = _get_user_by_id(msg.from_user.id)
    marzban_user = await marzban_api.get_user(username=username)
    if marzban_user:
        if telegram_user.is_sudo or marzban_user.admin.username == telegram_user.username:
            file = await storage.get_file_linked_to_user(username)

            traffic = f'{marzban_user.used_traffic}/{marzban_user.data_limit}' if marzban_user.data_limit else '∞'
            expiry_date = '∞' if not marzban_user.expire else utils.format_date(marzban_user.expire)

            if file and file.exists:
                last_sync = '-' if file.updated_at == -1 else utils.format_date(file.updated_at)
                drive_link = google_drive.get_download_link(file.file_id)
            else:
                last_sync = '-'
                drive_link = '-'

            await answer(msg, message.TELEGRAM_SEARCH_INFO.replace('{username}', marzban_user.username)
                         .replace('{traffic}', traffic).replace('{expire_at}', expiry_date)
                         .replace('{last_sync}', last_sync).replace('{link}', drive_link))

        else:
            # user in marzban found but telegram user cannot interact with him
            await answer(msg, message.TELEGRAM_SEARCH_NOT_FOUND)
    else:
        await answer(msg, message.TELEGRAM_SEARCH_NOT_FOUND)


async def send_message(user_id: int, msg: str):
    await bot.send_message(user_id, msg, parse_mode=ParseMode.MARKDOWN)


async def connect():
    await bot.delete_webhook(drop_pending_updates=True)
    await dispatcher.start_polling(bot, handle_signals=False)


async def shutdown():
    await bot.session.close()
    await dispatcher.stop_polling()
